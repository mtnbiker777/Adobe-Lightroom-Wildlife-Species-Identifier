return {
    LrSdkVersion = 9.0,
    LrToolkitIdentifier = 'com.jgalea.lightroom.googlevision',
    LrPluginName = "Wildlife & Species Identifier",

    -- Single source of truth for versioning (table required by Lightroom, display holds the string):
    VERSION = { major = 2026, minor = 11, revision = 0, display = "Nov 2026" },

    LrLibraryMenuItems = {
        {
            title = "Identify Species with Gemini",
            file = "InferImage.lua",
        },
        {
            title = "Configure Options",
            file = "ConfigureKey.lua",
        },
    },

    LrExportMenuItems = {
        {
            title = "Identify Species with Gemini",
            file = "InferImage.lua",
        },
        {
            title = "Configure Options",
            file = "ConfigureKey.lua",
        },
    },

    LrPluginInfoProvider = "PluginInfoProvider.lua",
}